import React, {useState} from 'react';
import './App.css';
import OnBtn from './components/OnBtns';
import { User } from './components/Users';
import {data} from './data'


function App() {
  const [age , setAge] = useState ('29');
  const renderUsers = () => {
    switch(age) {
      // 1 -render
      case "18" :
        let arr = data.filter((el) => {
          return el.age <= "18";
        });
        return arr.map((el,id) => {
          return <User data={el} key ={id}/>
        });
      // <render-2></render-2>
      case '24':
        let arr2 =data.filter((el) => {
          return el.age > '18' && el.age < '24';
        });
        return arr2.map((el,id) => {
          return <User data={el} key= {id} color = 'red' />
        });
      
      // render -3
      case "25":
        let arr3 =data.filter((el) => {
          return el.age >'25';
        })
        return arr3.map((el,id) => {
          return <User data ={el} key ={id} color="blue"/>
        });
      // render 4
      case "29":
        let arr4 = data.filter((el) => {
          return el.age <= "29";
        })
        return arr4.map((el,id) => {
          return <User data={el} key={id} color="darkred"/>
        });
      default:
        return "";
    }
  }
  

  return (
    <div className="App">
      <div className = "btns-groups">
        {/* btn-1 */}
      <button className="btn"
        onClick ={ ()=> setAge('18')}
        style={
          age >'18'?{backgroundColor: "blue"} : {backgroundColor: "none"}
        }
      >
        under-18 years </button>
        <OnBtn/>
        {/* btn-2 */}
      <button  className="btn"
        onClick ={() => setAge('24')}
        style={
          age >'18'&& age >'24' ?{backgroundColor: "red"} : {backgroundColor: "none"}
        }
      >
         18-24 years</button>
      {/* btn-3 */}
      <button  className="btn"
        onClick ={() => setAge('25')}
        style={
          age >='25'?{backgroundColor: "yellow"} : {backgroundColor: "none"}
        }
      >more-24 years</button>
      {/* btn-4 */}
      <button  className="btn"
        onClick ={() => setAge('29')}
        style={
          age <'29'?{backgroundColor: "silver"} : {backgroundColor: "none"}
        }
      >all years</button>
      </div>

      <div className = "containers">
      {
        renderUsers()
      //  data.map((el, id) => {
      //    return <User data ={el} key ={id} />
      //  })
     }
      </div>
    </div>
  )
 }

export default App;
