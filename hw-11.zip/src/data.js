import img1 from './images/img1.jpg'
import img2 from './images/img2.jpg'
import img3 from './images/img3.jpg'
import img4 from './images/img4.jpg'
import img5 from './images/img5.png'

export const data = [{
        img: img1,
        name: 'Baktyiar',
        age: 20,
        country: 'Kyrgyzstan',
    },
    {
        img: img2,
        name: 'Bektur',
        age: 21,
        country: 'Kazakstan',
    },
    {
        img: img3,
        name: 'Abzel',
        age: 25,
        country: 'Kyrgyzstan',
    },
    {
        img: img4,
        name: 'Edil',
        age: 17,
        country: 'Kyrgyzstan',
    },
    {
        img: img5,
        name: 'Aysen',
        age: 18,
        country: 'Uzbekistan',
    },
    {
        img: img1,
        name: 'Muhambet',
        age: 15,
        country: 'Kyrgyzstan',
    },
    {
        img: img5,
        name: 'Kajrat',
        age: 16,
        country: 'Turkey',
    },
    {
        img: img4,
        name: 'Ali',
        age: 25,
        country: 'Kyrgyzstan',
    },
    {
        name: 'Bahram',
        img: img3,
        age: 28,
        country: 'Uzbekistan',
    },
    {
        name: 'Schulz',
        img: img2,
        age: 29,
        country: 'Deutschland',
    },
    {
        name: 'John',
        img: img3,
        age: 20,
        country: 'USA',
    },
    {
        img: img4,
        name: 'Ali',
        age: 27,
        country: 'Kyrgyzstan',
    },
]