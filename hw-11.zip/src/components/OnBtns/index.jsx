import React from 'react'

function OnBtn() {
    return ( 
        <div >
            <button >Btn1</button>
            <button>Btn2</button>

        </div>
    )
}

export default OnBtn